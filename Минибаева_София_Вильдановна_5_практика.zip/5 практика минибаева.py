# 5 практика
import json
try:
    with open ("students.json", "r") as file:
        students = json.load(file)
        results = []
        for student in students:
            name = student["name"]
            grades = student["grades"]
            sr = sum(grades)/ len(grades)
            results.append({
                "name": name,
                "average": sr
            })
        scor = 0
    for result in results:
        scor += result["average"]
        overall_average = scor / len(results)

    with open ("report.json", "w") as file:
        report = {
            "students": results,
            "overall_average": overall_average
        }
        json.dump(report, file)
except FileNotFoundError:
    print("Файл не найден")
except KeyError:
    print("В данных студента отсутствует необходимый ключ")
if not isinstance(grades, list):
    raise TypeError("оценки не являются списком.")